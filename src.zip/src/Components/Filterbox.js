import React from "react";
import "../styles/Filterbox.css";

const Filterbox = () => {
  return (
    <div className="filterBox">
      <div className="colorBox">
        <h2>Color</h2>

        <div>
          <input type="checkbox" />
          <label>Red</label>
        </div>

        <div>
          <input type="checkbox" />
          <label>Blue</label>
        </div>

        <div>
          <input type="checkbox" />
          <label>Green</label>
        </div>
      </div>

      <div className="genderBox">
        <h2>Gender</h2>

        <div>
          <input type="checkbox" />
          <label>Male</label>
        </div>

        <div>
          <input type="checkbox" />
          <label>Female</label>
        </div>
      </div>

      <div className="priceBox">
        <h2>Price</h2>

        <div>
          <input type="checkbox" />
          <label>0 - 250</label>
        </div>

        <div>
          <input type="checkbox" />
          <label>251 - 450</label>
        </div>

        <div>
          <input type="checkbox" />
          <label>Above 450</label>
        </div>
      </div>

      <div className="typeBox">
        <h2>Type</h2>

        <div>
          <input type="checkbox" />
          <label>Polo</label>
        </div>

        <div>
          <input type="checkbox" />
          <label>Hoodie</label>
        </div>

        <div>
          <input type="checkbox" />
          <label>Basic</label>
        </div>
      </div>
    </div>
  );
};

export default Filterbox;
