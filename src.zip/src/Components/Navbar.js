import React from "react";
import "../styles/Navbar.css";
import { useNavigate } from "react-router-dom";

const Navbar = () => {
  const navigate = useNavigate();

  return (
    <div className="navBar">
      <h1>TeeRex Store</h1>
      <div className="account">
        <h2
          onClick={() => {
            navigate("/");
          }}
        >
          Products
        </h2>
        <h2
          onClick={() => {
            navigate("/cart");
          }}
        >
          Cart
        </h2>
      </div>
    </div>
  );
};

export default Navbar;
